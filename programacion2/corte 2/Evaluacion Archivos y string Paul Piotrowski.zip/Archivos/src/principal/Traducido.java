package principal;
import java.util.*;
import java.io.*;
public class Traducido {
	//Declarar variables
	public String palabra_es;//Para palabras en espanol
	public String palabra_en;//Para palabras en ingles
	
	public static int contador_traducidas = 0;
	public static int contador_no_traducidas = 0;
	public static int errores = 0;
	public static Scanner sc = new Scanner(System.in);
	public static Traducido [] lista_pal = new Traducido[100];//Lista donde se guardan las palabras
	public static Traducido [] lista_tra = new Traducido[100];//Lista donde se guardan las palabras que se tradujeron
	public static Traducido[] lista_no_tra = new Traducido[100];//Lista donde se guardan las palabras que se tradujeron
	//Objeto donde se guardan las palabras
	public Traducido(String palabra_es, String palabra_en) {
	this.palabra_en = palabra_en;
	this.palabra_es = palabra_es;
	
	}
	
	
	public static void main(String[] args) throws IOException {
	    programa();
	}
	 //Ejecutar el programa	
	public static void programa() {
		int i = 0;
	    datos();
	    System.out.println("Bienvendido user. Introduzca la cantidad de palabras que desee traducir: ");
	    int opcion = sc.nextInt();
	    boolean verdad = true;
		do {
	        System.out.println("Bienvendido user. Introduzca la palabra a traducir, ya sea en espanol o ingles: ");
	        String pregunta = sc.next();
        	
	        //Para mostrar mensaje de error
	        if(buscar(pregunta) != true) {
	        	System.err.println("La palabra introducida no esta en la lista");
	        	System.err.println("Press Enter To Continue...");
				new java.util.Scanner(System.in).nextLine();
	        	}
	        i++;//Contador
	        //Para terminar el bucle
        	if(i == opcion) {
        		verdad = false;
        	}
	    }while(verdad);
	    errores = opcion - contador_traducidas; //Para saber el numero de errores
	    contador_no_traducidas = 15 - contador_traducidas; //Para saber el numero de palabras no traducidas
	    imprimirDatos();
	}
	
	//Funcion para revelar los datos del objeto
	 	public static void getDatos(String palabra_es, String palabra_en) {
	 		System.out.println("La palabra en espanol es: " + palabra_es + ". La palabra traducida es: " + palabra_en );
	 	}
	 	
	 	
	 //PAra ponerle datos a la lista de palabras
	 public static void datos() {
		 try {
		 	File file = new File("src\\principal\\Palabras_no_traducidas.txt");//File no traducido
	        File file_en = new File("src\\principal\\Palabrastraducidas.txt");//File traducido
	        Scanner scanner;
	        Scanner scanner_2;
	   
	        //se pasa el flujo al objeto scanner
		    scanner = new Scanner(file);
		    scanner_2 = new Scanner(file_en);

     		// el objeto scanner lee linea a linea desde el archivo
     		String linea_es = scanner.nextLine();//Para obtener toda la linea
     		String linea_en_trad = scanner_2.nextLine();//Para obtener toda la linea
     		String[] espanol = linea_es.split(",\\s");//PAra obtener las palabras una por una
     		String[] ingles = linea_en_trad.split(",\\s");//PAra obtener las palabras una por una
			 for(int k = 0; k<15; k++) {
				String linea = espanol[k]; //Para saber la palabra
				String linea_en = ingles[k]; //Para saber la palabra
				lista_pal[k] = new Traducido(linea, linea_en);
	     		
			 }//se cierra el objeto scanner
			    scanner.close();
			    scanner_2.close();
			    
			} catch (Exception e) {
				e.printStackTrace();
		            
			}
	}

	 //Para imprimir los datos en un documetno de texto
	 public static void imprimirDatos() {
		 try {
		 	String ruta = "src\\principal\\estadisticas.txt";
	        File archivo = new File(ruta);
	        BufferedWriter bw;
	      //Primeros datos a imprimir
            String datos = "Datos estadisticos del programa: \n1. Palabras no traducidas: "+ contador_no_traducidas ;
            String datos_2 = "\n2. Palabras traducidas: "
            		+contador_traducidas + "\n"
            		+ "3. Errores: " + errores;
				bw = new BufferedWriter(new FileWriter(archivo));
			
            bw.write(datos);//Para escribir
            verificar();
            //Para imprimir las palabras que no se tradujeron se usa un bucle fot y un condicional
            for(int i = 0; i<=contador_no_traducidas; i++) {
            	if(lista_no_tra[i] != null) {
            		bw.write("\nPalabra en espanol: " + lista_no_tra[i].palabra_es + ", y en ingles: " + lista_no_tra[i].palabra_en);
            	}
            }
            
          //Para escribir
            bw.write(datos_2);
            bw.close();//Cerrar el archivo
		 } catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
	 
	//condicional para comparar la pregunta con el texto de la linea e imprimir el texto en ingles
	 public static boolean buscar(String pregunta) {
		 for(int l = 0; l < 15; l++) {
	        	if(lista_pal[l].palabra_es.equals(pregunta)) {
	        		//System.out.println(linea_en); //Otra forma, en este caso no se usa objeto, sino simplemente otra variable
	        		getDatos(lista_pal[l].palabra_es, lista_pal[l].palabra_en);
	        		Traducido ejemplo = new Traducido(lista_pal[l].palabra_es, lista_pal[l].palabra_en);
	        		lista_tra[l] = ejemplo;
	        		
	        		contador_traducidas++;
	        		System.out.println("Press Enter To Continue...");
					new java.util.Scanner(System.in).nextLine();
					return true;
	        	} 
	        	else if(lista_pal[l].palabra_en.equals(pregunta)) {
	        		//System.out.println(linea_en); //Otra forma, en este caso no se usa objeto, sino simplemente otra variable
	        		getDatos(lista_pal[l].palabra_es, lista_pal[l].palabra_en);
	        		contador_traducidas++;
	        		Traducido ejemplo = new Traducido(lista_pal[l].palabra_es, lista_pal[l].palabra_en);
	        		lista_tra[l] = ejemplo;
	        		System.out.println("Press Enter To Continue...");
					new java.util.Scanner(System.in).nextLine();
					return true;
	        	} 
	        	
	        }
		 return false;
	 }

	 //Para verificar si la palabra se tradujo o no
	 public static void verificar() {
		 
		 for(int i = 0; i<15; i++) {
			 if(lista_tra[i] == null) {
				 Traducido ejemplo = new Traducido(lista_pal[i].palabra_es, lista_pal[i].palabra_en);
				 lista_no_tra[i] = ejemplo;
			 }
		 }
		 return;
	 }

}



	 
