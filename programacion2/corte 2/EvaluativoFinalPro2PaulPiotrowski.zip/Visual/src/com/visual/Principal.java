package com.visual;
import java.util.*;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JCheckBox;
import javax.swing.JToggleButton;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JPopupMenu;
import java.awt.Component;
import java.awt.Desktop;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;

import javax.swing.JMenuItem;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.awt.Checkbox;
import com.toedter.calendar.JDateChooser;
import javax.swing.border.BevelBorder;
import javax.swing.ListSelectionModel;
import javax.swing.border.CompoundBorder;
import javax.swing.JScrollPane;
import javax.swing.border.LineBorder;
import java.awt.Color;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
public class Principal {

	private JFrame frmPokemones;
	private JTextField txtNombre;
	private JTextField txtNum;
	private static JTable table;
	private JComboBox tipo_2;
	public static Object [] todos =  new Object[100];//Para agregar todos los pokemones que obtengamos en una lista
	
	//Listas
	
	public static String[] nombre_pok = new String[100];
	public static String[] numero_pok = new String[100];
	public static String[] tipo_pok_1 = new String[100];
	public static String[] tipo_pok_2 = new String[100];
	public static String[] equipo_pok = new String[100];
	public static String[] sexo_pok = new String[100];
	public static String[] region_pok = new String[100];
	public static String[] fecha_pok = new String[100];
	public static Calendar[] lista_cal = new Calendar[100];
	public static int o = 0;//Contador
	public int k = 0;//Contador para modificar
	//Crear un grupo de botones para que solo haya uno seleccionado
	public static ButtonGroup grupo = new ButtonGroup();
	static int maximo = 6;//Contador para maximo num de si
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Principal window = new Principal();
					window.frmPokemones.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Principal() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmPokemones = new JFrame();
		frmPokemones.setFont(new Font("Arial", Font.BOLD, 12));
		frmPokemones.setTitle("Pokemones");
		frmPokemones.setBounds(100, 100, 642, 491);
		frmPokemones.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel panel = new JPanel();
		frmPokemones.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		txtNombre = new JTextField();
		txtNombre.setBounds(39, 58, 248, 33);
		panel.add(txtNombre);
		txtNombre.setColumns(10);
		
		txtNum = new JTextField();
		txtNum.setBounds(374, 58, 242, 33);
		txtNum.setColumns(10);
		panel.add(txtNum);
		
		JLabel labelNombre = new JLabel("Nombre");
		labelNombre.setBounds(39, 33, 46, 14);
		panel.add(labelNombre);
		
		JLabel labelNumero = new JLabel("Numero");
		labelNumero.setBounds(374, 33, 46, 14);
		panel.add(labelNumero);
		
		JLabel lblNewLabel = new JLabel("Tipo");
		lblNewLabel.setBounds(39, 102, 46, 14);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Tipo");
		lblNewLabel_1.setBounds(374, 102, 46, 14);
		panel.add(lblNewLabel_1);
		
		JComboBox tipo_1 = new JComboBox();
		tipo_1.setModel(new DefaultComboBoxModel(new String[] {"Acero", "Agua", "Bicho", "Drag\u00F3n", "El\u00E9ctrico", "Fantasma", "Fuego", "Hada", "Hielo", "Lucha", "Normal", "Planta", "Ps\u00EDquico", "Roca", "Siniestro", "Tierra", "Veneno", "Volador"}));
		tipo_1.setBounds(39, 127, 248, 33);
		panel.add(tipo_1);
		
		tipo_2 = new JComboBox();
		tipo_2.setModel(new DefaultComboBoxModel(new String[] {"Acero", "Agua", "Bicho", "Drag\u00F3n", "El\u00E9ctrico", "Fantasma", "Fuego", "Hada", "Hielo", "Lucha", "Normal", "Planta", "Ps\u00EDquico", "Roca", "Siniestro", "Tierra", "Veneno", "Volador"}));
		tipo_2.setBounds(374, 127, 242, 33);
		panel.add(tipo_2);
		
		JLabel lblSexo = new JLabel("Sexo");
		lblSexo.setBounds(39, 171, 46, 14);
		panel.add(lblSexo);
		
		JComboBox sexo = new JComboBox();
		sexo.setModel(new DefaultComboBoxModel(new String[] {"Macho", "Hembra", "No tiene"}));
		sexo.setBounds(39, 196, 248, 33);
		panel.add(sexo);
		
		JComboBox region = new JComboBox();
		region.setModel(new DefaultComboBoxModel(new String[] {"Kanto", "Islas Sete", "Johto", "Hoenn", "Sinnoh", "Teselia", "Kalos", "Alola", "Galar"}));
		region.setBounds(39, 265, 248, 33);
		panel.add(region);
		
		JLabel lblRegion = new JLabel("Region");
		lblRegion.setBounds(39, 240, 46, 14);
		panel.add(lblRegion);
		
		JLabel lblFecha = new JLabel("Fecha");
		lblFecha.setBounds(374, 171, 46, 14);
		panel.add(lblFecha);
		
		JLabel lblEquipo = new JLabel("Equipo");
		lblEquipo.setBounds(374, 240, 46, 14);
		panel.add(lblEquipo);
		
		JButton btnLimpiar = new JButton("Limpiar");
		btnLimpiar.setBounds(57, 326, 143, 33);
		panel.add(btnLimpiar);
		//boton de modificar
		JButton btnModificar = new JButton("Modificar");
		
		btnModificar.setBounds(225, 326, 143, 33);
		panel.add(btnModificar);
		//Boton de agregar objeto a la tabla
		JButton btnAgregar = new JButton("Agregar");
		btnAgregar.setBounds(405, 326, 143, 33);
		panel.add(btnAgregar);
		
		//Crear jcalendar
		JDateChooser fecha = new JDateChooser();
		fecha.setBounds(374, 196, 242, 33);
		panel.add(fecha);
		
		JScrollPane scrollPane = new JScrollPane();
		
		scrollPane.setBounds(57, 370, 491, 71);
		panel.add(scrollPane);
		
		//Crear tabla
		
		table = new JTable();
		table.setDefaultEditor(Object.class, null);
		table.setRowSelectionAllowed(true);
		table.setCellSelectionEnabled(false);
		table.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
		table.setBorder(new LineBorder(new Color(0, 0, 0)));
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Numero", "Nombre", "Sexo", "Region", "Equipo"
			}
		));
		scrollPane.setViewportView(table);
		//Boton de abrir 
		JButton btnAbrir = new JButton("Abrir");
		btnAbrir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				imprimirDatos();
				abrirDatos("src\\com\\visual\\pokemones.txt");
			}
		});
		btnAbrir.setBounds(0, 0, 128, 33);
		panel.add(btnAbrir);
		//Boton de guardar archivo de texto
		JButton btnGuardar = new JButton("Guardar");
		btnGuardar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				imprimirDatos();
			}
		});
		btnGuardar.setBounds(127, 0, 128, 33);
		panel.add(btnGuardar);
		//Checkboxes
		JCheckBox checkSi = new JCheckBox("Si");
		checkSi.setBounds(374, 270, 97, 23);
		panel.add(checkSi);
		
		JCheckBox checkNo = new JCheckBox("No");
		checkNo.setBounds(489, 270, 97, 23);
		panel.add(checkNo);
		
		grupo.add(checkSi);
		grupo.add(checkNo);
		
		//Validaciones-------------------------------------------
		
		
		
		btnAgregar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String txtNom = txtNombre.getText();
				String txtNumStr = txtNum.getText();
				int contador = 0;
				//Para que se valide si tienen valor las cosa
				if(txtNumStr.equals("")) {
					JOptionPane.showMessageDialog(null, "El numero esta vacio");
					contador++;
				}
				else if(txtNom.equals("")) {
					JOptionPane.showMessageDialog(null, "El nombre esta vacio");
					contador++;
				}
				else if(fecha.getDate() == null) {
					JOptionPane.showMessageDialog(null, "La fecha esta vacia");
					contador++;
				}
				else if(checkSi.isSelected() == false && checkNo.isSelected() == false) {
					JOptionPane.showMessageDialog(null, "Selecciona si esta en el equipo");
					contador++;
				}
				else {
					 if(isNumber(txtNumStr) == false) {
						JOptionPane.showMessageDialog(null, "En el cuadro de text de numero fue introducido un texto");
						contador++;
					 }
				}

				Calendar cal_pok = fecha.getCalendar();//Para obtener la fecha en calendar
				//Para obtener la fecha en String
				Date date = fecha.getDate();

				String strDate = DateFormat.getDateInstance().format(date);
				//Agregar los vvalores a la tabla
				int numCols = 8;
				//Objeto donde se agregaran los valores de cada pokemon
				Object [] fila = new Object[numCols]; 
				        
				fila[0] = txtNumStr;
				fila[1] = txtNom;
				fila[2] = sexo.getSelectedItem();
				fila[3] = region.getSelectedItem();
				fila[4] = (checkSi.isSelected() == true)?"Si":"No";
				
				if(comprobarPok() == true) {
					nombre_pok[o] = txtNom;
					numero_pok[o] = txtNumStr;
					tipo_pok_1[o] = (String) tipo_1.getSelectedItem();
					tipo_pok_2[o] =  (String) tipo_2.getSelectedItem();
					equipo_pok[o] = (checkSi.isSelected() == true)?"Si":"No";
					sexo_pok[o] = (String) sexo.getSelectedItem();
					region_pok[o] = (String) region.getSelectedItem();
					fecha_pok[o] = strDate;
					lista_cal[o] = cal_pok;
					o++;	
					//Para verificar que se haya agregado todos los valores antes de a�adirlos a la tabla
					if(contador == 0) {
						((DefaultTableModel) table.getModel()).addRow(fila);//A�adir valores a la tabla
					}
				}
			}
		});
		
		
		//Para limpiar los cuadros de texto y listas
		btnLimpiar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtNombre.setText("");
				txtNum.setText("");
				fecha.setCalendar(null);
				region.setSelectedIndex(0);
				tipo_1.setSelectedIndex(0);
				tipo_2.setSelectedIndex(0);
				sexo.setSelectedIndex(0);
				grupo.clearSelection();
			}
		});
		
		//Para modiifcar una fila
		//Al seleccionar fila
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				k = table.getSelectedRow();
			
				if(equipo_pok[k].equals("Si")) {
					checkSi.setSelected(true);
				}
				else {
					checkNo.setSelected(true);
				}
				
				txtNombre.setText(table.getValueAt(k,1).toString());
				txtNum.setText(table.getValueAt(k,0).toString());
				sexo.setSelectedItem(sexo_pok[k]);
				region.setSelectedItem(region_pok[k]);
				tipo_1.setSelectedItem(tipo_pok_1[k]);
				tipo_2.setSelectedItem(tipo_pok_2[k]);
				fecha.setCalendar(lista_cal[k]);
				
			}
		});
		//Al presionar el boton de modiifcar 
		btnModificar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) { //Para evento de modificar dato de fila de tabla

				String txtNom = txtNombre.getText();
				String txtNumStr = txtNum.getText();	
				
				int contador = 0;
				//Para que se valide si tienen valor las cosa
				if(txtNumStr.equals("")) {
					JOptionPane.showMessageDialog(null, "El numero esta vacio");
					contador++;
				}
				else if(txtNom.equals("")) {
					JOptionPane.showMessageDialog(null, "El nombre esta vacio");
					contador++;
				}
				else if(fecha.getDate() == null) {
					JOptionPane.showMessageDialog(null, "La fecha esta vacia");
					contador++;
				}
				else if(checkSi.isSelected() == false && checkNo.isSelected() == false) {
					JOptionPane.showMessageDialog(null, "Selecciona si esta en el equipo");
					contador++;
				}
				else {
					 if(isNumber(txtNumStr) == false) {
						JOptionPane.showMessageDialog(null, "En el cuadro de text de numero fue introducido un texto");
						contador++;
					 }
				}
				
				//Para obtener la fecha en String
				Date date = fecha.getDate();
				Calendar cal_pok = fecha.getCalendar();//Para obtener la fecha en calendar
				String strDate = DateFormat.getDateInstance().format(date);
				//Agregar los vvalores a la tabla
				int numCols = 8;
				//Objeto donde se agregaran los valores de cada pokemon
				Object [] fila = new Object[numCols]; 
				        
				fila[0] = txtNumStr;
				fila[1] = txtNom;
				fila[2] = sexo.getSelectedItem();
				fila[3] = region.getSelectedItem();
				fila[4] = (checkSi.isSelected() == true)?"Si":"No";
				
					nombre_pok[k] = txtNom;
					numero_pok[k] = txtNumStr;
					tipo_pok_1[k] = (String) tipo_1.getSelectedItem();
					tipo_pok_2[k] =  (String) tipo_2.getSelectedItem();
					equipo_pok[k] = (checkSi.isSelected() == true)?"Si":"No";
					sexo_pok[k] = (String) sexo.getSelectedItem();
					region_pok[k] = (String) region.getSelectedItem();
					fecha_pok[k] = strDate;
					lista_cal[k] = cal_pok;
					//Para verificar que se haya agregado todos los valores antes de a�adirlos a la tabla
					if(contador == 0) {
						for(int i = 0; i<5;i++) {
							table.getModel().setValueAt(fila[i], k, i);
						}
					}
				
			}
		});

	}
	
	//Para revisar que sea numeros la parte de Num
	public boolean isNumber(String num) {
		if(num == null) {
			return false;
		}
		try {
			Double.parseDouble(num);
		}catch(NumberFormatException e) {
			
			return false;
		}
	return true;
	}
	//Guardar los datos
	public static void imprimirDatos() {
		 try {
			
		 	String ruta = "src\\com\\visual\\pokemones.txt";
		 	int l = table.getModel().getRowCount();
		 	
	        File archivo = new File(ruta);
	        BufferedWriter bw;
	      //Primeros datos a imprimir
           
	        bw = new BufferedWriter(new FileWriter(archivo));
			
	       
           
           //Para imprimir las palabras se usa un bucle for
           for(int i = 0; i<l; i++) {
        	   bw.write("El nombre es: " + nombre_pok[i] + ", el numero es: " + numero_pok[i] + ", el sexo es: " + sexo_pok[i]+  ", la region es: " + region_pok[i] + " , si esta en el equipo: " + equipo_pok[i] + " , la fecha de recogida es: " + fecha_pok[i] + ", el tipo 1 es: " + tipo_pok_1[i] + ", el tipo 2 es: " + tipo_pok_2[i] + "\n\n");
           }
           
         
           
           bw.close();//Cerrar el archivo
		 } catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
	//Para comprobar el numero de pokemones en el equipo
	public static boolean comprobarPok() {
		
		int contador_pok = 0;
		for(int i = 0; i < o; i++) {
			if(equipo_pok[i].equals("Si")) {
				contador_pok++;
			}
		}
		if(contador_pok == maximo) {
			JOptionPane.showMessageDialog(null, "Hay demasiados pokemones en el equipo, no se pueden agregar mas.");
			return false;				
		}
		return true;
	}
	
	
	//Abrir archivo de texto
	public static void abrirDatos(String archivo) {
		try {
			//Abrir objeto file
            File ruta = new File (archivo);
            Desktop.getDesktop().open(ruta);//Para abrir el archivo txt se usa este metodo

     }catch (IOException ex) {

            System.out.println(ex);

     	}
	}
	private static void addPopup(Component component, final JPopupMenu popup) {
	}
}
