//Programa para hacer un inventario
package arreglos;

import java.util.Scanner;

public class Nuevoarreglo {

	public static void main(String[] args) {
	
		//Declarar variables
		Double precio_USD = 3100000.00;
		char caso;
		int can_prod = 100, opcion, contador = 0;
		String producto = "N";
		Scanner sc = new Scanner(System.in);
		//Declarar listas 
		String[] lista_prod = new String[can_prod];//Lista de nombres de productos
		int[] lista_can = new int[can_prod];//Lista de cantidades de productos
		int[] lista_cod = new int[can_prod];//Lista de codigos de productos
		Double[] lista_preVES = new Double[can_prod];//Lista de precios en Bolivares Soberanos de productos
		Double[] lista_preUSD = new Double[can_prod];//Lista de precios en Dolares Americanos de productos
		
		//Bucle do-while para que el programa corra al menos una vez
		do {
			//Mensaje de bienvenida
			System.out.println("Bienvenido al programa User!\nElija una opcion.\n1.Lista de productos\n2.Editar productos.\n3.Total Bruto(VES/USD)\n4.Configuraciones de tasa de cambio.\n5.Salir del programa.");
			opcion = sc.nextInt();
			
			//condicional para cada opcion del menu
			switch (opcion) {
				
				//Para leer las listas
				case 1:{
					for(int i = 0; i<can_prod; i++) {
						System.out.println("Producto["+ i + "]: " + lista_prod[i]);
						System.out.println("Cantidad["+ i + "]: " + lista_can[i]);
						System.out.println("Codigo["+ i + "]: " + lista_cod[i]);
						System.out.println("Precio(USD)["+ i + "]: " + lista_preUSD[i]);
					}
					
					System.out.println("Press Enter To Continue...");
        			new java.util.Scanner(System.in).nextLine();
					continue;
				}
				//Para introducir los datos a las listas
				case 2:
				{
					int o, p = 0;
					System.out.println("Bienvenido a la opcion para agregar productos.\n0. Producto nuevo.\n1. Producto ya colocado.");
					p = sc.nextInt();
					
					//Si se introducen los datos de un producto nuevo
					if (p == 0) {
						System.out.println("Introduzca el numero de productos que va a agregar");
						o = sc.nextInt();
						for (int j = 0; j < o; j++) {
							System.out.println("Introduzca el nombre del producto");
							lista_prod[contador] = sc.next();
							System.out.println("Introduzca el numero del codigo");
							lista_cod[contador] = sc.nextInt();
							System.out.println("Introduzca el precio del producto en bolivares");
							lista_preVES[contador] = sc.nextDouble();
							lista_preUSD[contador] = lista_preVES[contador] * precio_USD;
							System.out.println("Introduzca la cantidad de productos");
							lista_can[contador] = sc.nextInt();
							contador++;
						}
					}
					
					else {//else por si quiere modificar un dato de un producto
						
						System.out.println("Introduzca el numero del orden del producto, si es el primero coloque 0");
						p= sc.nextInt();
						System.out.println("Menu de opciones de cambio.\n1. Nombre.\n2. Codigo.\n3. Precio.\n 4. Cantidad.");
						o= sc.nextInt();
						
						//Condicional switch para editar los productos
						switch (o) {
							//Para cambiar el nombre
							case 1:
								System.out.println("Introduzca el nombre del producto");
								lista_prod[p] = sc.next();
								continue;
								
							//Para cambiar el numero de codigo
							case 2:
								System.out.println("Introduzca el numero del codigo");
								lista_cod[p] = sc.nextInt();
								continue;

							//Para cambiar el precio del producto
							case 3: 
								System.out.println("Introduzca el precio del producto en bolivares");
								lista_preVES[p] = sc.nextDouble();
								lista_preUSD[p] = lista_preVES[p] * precio_USD;
								continue;
								
							//Para cambiar la cantidad de productos
							case 4: 		
								System.out.println("Introduzca la cantidad de productos");
								lista_can[p] = sc.nextInt();
								continue;
							default:
								System.out.println("Ha colocado mal un dato.");
								continue;
							}
						}
					can_prod = contador;//Para que la cantidad de productos totales coincida con el tama�o de las listas
					System.out.println("Press Enter To Continue...");
					new java.util.Scanner(System.in).nextLine();
					continue;
				}
				
				//Para ver el precio bruto
				case 3:
				{
					Double k = 0.00, w = 0.00;
					System.out.println("Bienvenido a la opcion de ver el precio bruto de los productos del inventario.");
					
					for(int s =0; s<can_prod; s++) {
						w += lista_preVES[s] * lista_can[s];
						k += lista_preUSD[s] * lista_can[s];
					}
					//Condicional para que se muestre el precio bruto del inventario de ese producto
					if (contador != 0) {
						System.out.println("El precio bruto del inventario de productos en VES y USD es: \nVES: "+ w + "\nUSD: " + k);
					} 
					else{
						System.out.print("No has introducido ningun producto en la lista.");
					}
					System.out.println("Press Enter To Continue...");
					new java.util.Scanner(System.in).nextLine();
					continue;
				}
				//Para las configuraciones
				case 4:
				
					System.out.println("Bienvenido a la opcion de configuracion.\na. Configuracion del precio del dolar.\n");
					caso = sc.next().charAt(0);
						switch(caso){
							//Para el precio del dolar
							case 'a':
								System.out.println("Bienvenido a la opcion de modificar el precio del dolar\nColoque un nuevo precio: ");
								precio_USD = sc.nextDouble();

								System.out.println("El nuevo precio de dolar en VES es: " + precio_USD);
								
								//Condicional para que no se cambie nada si no se ha agregado ningun producto
								if(contador != 0) {
									for (int k = 0; k < can_prod; k++) {
										lista_preUSD[k] = lista_preVES[k] * precio_USD;
									}									
								}
								System.out.println("Press Enter To Continue...");
								new java.util.Scanner(System.in).nextLine();
								continue;
							
							default:
								System.out.println("Ha introducido mal un dato");
								System.out.println("Press Enter To Continue...");
								new java.util.Scanner(System.in).nextLine();
								continue;
						}
					
					//Para salir del programa
				case 5:
					System.out.println("Hasta luego user!");
					producto = "Y";
					System.out.println("Press Enter To Continue...");
					new java.util.Scanner(System.in).nextLine();
					break;

				default:
					System.out.println("Has introducido mal un dato.");
					continue;
			}
			
		} while(producto.equals("N"));
		}
		
	}

